var ErrataList;
var ErrataLength;

const correction_recurr = function (super_paragraph) {
  let paragraph = super_paragraph.childNodes;
  for (let i = 0; i < paragraph.length; i++) {
    if (paragraph[i].nodeType == Node.TEXT_NODE) {
      if (paragraph[i].textContent.trim()) {
        for (let j = 0; j < ErrataLength; j++) {
          paragraph[i].textContent = paragraph[i].textContent.replace(new RegExp(ErrataList[j][0], "gi"), ErrataList[j][1]);
        }
      }
    } else if (paragraph[i].nodeType == Node.ELEMENT_NODE) {
      const tagName = paragraph[i].tagName;
      if (tagName != "STYLE" && tagName != "SCRIPT" && tagName != "LINK") {
        if (tagName != "IMG" && tagName != "A" && tagName != "INPUT") {
          correction_recurr(paragraph[i]);
        }
      }
    }
  }
};

if (document.documentElement.lang == "ko") {
  const url = chrome.runtime.getURL("data/ErrataList.csv");
  $.get(url, function (data) {
    ErrataList = $.csv.toArrays(data);
    ErrataLength = ErrataList.length;

    // console.time("ko_ErrataCorrection");
    correction_recurr(document.body);
    // console.timeEnd("ko_ErrataCorrection");
  });
}
