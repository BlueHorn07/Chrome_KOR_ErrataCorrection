let ErrataList;

const generateThead = function(table){
  let thead = table.createTHead();
  let thead_row = thead.insertRow();

  let thead_idx_cell = document.createElement('th');
  let thead_idx_text = document.createTextNode("#");
  thead_idx_cell.appendChild(thead_idx_text);
  thead_row.appendChild(thead_idx_cell);

  let thead_errata_cell = document.createElement('th');
  let thead_errata_text = document.createTextNode("Errata");
  thead_errata_cell.appendChild(thead_errata_text);
  thead_row.appendChild(thead_errata_cell);

  let thead_correction_cell = document.createElement('th');
  let thead_correction_text = document.createTextNode("Correction");
  thead_correction_cell.appendChild(thead_correction_text);
  thead_row.appendChild(thead_correction_cell);
}

const generateTbody = function(table){
  let tbody = document.createElement("tbody");
  for (let i = 1; i < ErrataList.length; i++) {
    let row = tbody.insertRow();

    let idx_cell = row.insertCell();
    let idx_text = document.createTextNode(i);
    idx_cell.appendChild(idx_text);

    let errata_cell = row.insertCell();
    let errata_text = document.createTextNode(ErrataList[i][0]);
    errata_cell.appendChild(errata_text);

    let correction_cell = row.insertCell();
    let correction_text = document.createTextNode(ErrataList[i][1]);
    correction_cell.appendChild(correction_text);
    row.innerHTML = row.innerHTML.replace(/ /g, `<span style="background-color: #FFDD81">&nbsp;</span>`);
  }
  table.appendChild(tbody);
}

const url = chrome.runtime.getURL("data/ErrataList.csv");
$.get(url, function (data) {
  ErrataList = $.csv.toArrays(data);
  let table = document.getElementById("ErrataList");

  generateThead(table);
  generateTbody(table);

  
});
